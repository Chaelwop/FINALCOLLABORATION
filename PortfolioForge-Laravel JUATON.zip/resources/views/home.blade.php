@extends('layouts.app')

@section('content')
<section class="hero">
    <div class="max-w-6xl mx-auto px-6 py-24 grid lg:grid-cols-2 gap-12 items-center">
        <div>
            <span class="eyebrow">LARAVEL • CRUD • ONLINE DATABASE</span>
            <h1 class="hero-title">Build a portfolio that looks <span>like you.</span></h1>
            <p class="hero-text">PortfolioForge lets you enter your information once, save it online, choose one of three designs, and instantly generate your portfolio.</p>
            <div class="flex flex-wrap gap-3 mt-8">
                <a href="{{ route('portfolio.create') }}" class="primary-btn">Create My Portfolio →</a>
                <a href="{{ route('portfolio.manage') }}" class="secondary-btn">Manage Portfolios</a>
            </div>
        </div>
        <div class="preview-card">
            <div class="preview-top"></div>
            <div class="preview-body">
                <div class="preview-avatar"></div>
                <div class="h-4 bg-white/20 rounded w-2/3"></div>
                <div class="h-3 bg-white/10 rounded w-1/2 mt-3"></div>
                <div class="grid grid-cols-3 gap-3 mt-8">
                    <div class="h-20 bg-cyan-400/10 rounded-xl"></div>
                    <div class="h-20 bg-violet-400/10 rounded-xl"></div>
                    <div class="h-20 bg-emerald-400/10 rounded-xl"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="max-w-6xl mx-auto px-6 py-16">
    <h2 class="section-title">Everything required by the project</h2>
    <div class="grid md:grid-cols-3 gap-5 mt-8">
        <div class="feature-card"><b>01 · Information</b><p>Personal details, education, skills, projects, experience and links.</p></div>
        <div class="feature-card"><b>02 · Three Templates</b><p>Simple, Modern and Creative designs with noticeably different layouts.</p></div>
        <div class="feature-card"><b>03 · CRUD</b><p>Create, save, retrieve, edit and delete portfolio records.</p></div>
    </div>
</section>
@endsection
