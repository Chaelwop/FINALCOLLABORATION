@csrf
@if(isset($portfolio)) @method('PUT') @endif

<div class="form-section">
    <h2>Personal Information</h2>
    <div class="grid md:grid-cols-2 gap-5">
        <label>Full Name <input name="full_name" value="{{ old('full_name', $portfolio->full_name ?? '') }}" required></label>
        <label>Email <input type="email" name="email" value="{{ old('email', $portfolio->email ?? '') }}" required></label>
        <label>Contact Number <input name="contact_number" value="{{ old('contact_number', $portfolio->contact_number ?? '') }}"></label>
        <label>Address <input name="address" value="{{ old('address', $portfolio->address ?? '') }}"></label>
        <label class="md:col-span-2">Profile Picture <input type="file" name="profile_picture" accept="image/*"></label>
        <label class="md:col-span-2">About Me <textarea name="about_me" rows="5">{{ old('about_me', $portfolio->about_me ?? '') }}</textarea></label>
    </div>
</div>

<div class="form-section">
    <h2>Education, Skills & Experience</h2>
    <p class="helper">Put one item per line. Example: Bachelor of Science in Information Technology — CEC.</p>
    <div class="grid md:grid-cols-2 gap-5">
        <label>Educational Background <textarea name="education" rows="5">{{ old('education', isset($portfolio) ? implode("\n", $portfolio->education ?? []) : '') }}</textarea></label>
        <label>Skills <textarea name="skills" rows="5">{{ old('skills', isset($portfolio) ? implode("\n", $portfolio->skills ?? []) : '') }}</textarea></label>
        <label>Work Experience <textarea name="work_experience" rows="5">{{ old('work_experience', isset($portfolio) ? implode("\n", $portfolio->work_experience ?? []) : '') }}</textarea></label>
        <label>Social Media / Website Links <textarea name="social_links" rows="5" placeholder="https://github.com/yourname&#10;https://linkedin.com/in/yourname">{{ old('social_links', isset($portfolio) ? implode("\n", $portfolio->social_links ?? []) : '') }}</textarea></label>
    </div>
</div>

<div class="form-section">
    <h2>Projects</h2>
    <p class="helper">One project per line. Example: Inventory Management System — Web-based stock monitoring application.</p>
    <textarea name="projects" rows="7">{{ old('projects', isset($portfolio) ? implode("\n", $portfolio->projects ?? []) : '') }}</textarea>
</div>

<button class="primary-btn w-full md:w-auto">{{ isset($portfolio) ? 'Save Changes' : 'Save Portfolio Information' }} →</button>
