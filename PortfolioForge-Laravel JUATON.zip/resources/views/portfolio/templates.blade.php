@extends('layouts.app')
@section('content')
<div class="max-w-6xl mx-auto px-6 py-12">
    <div class="text-center mb-12"><span class="eyebrow">STEP 2 OF 2</span><h1 class="page-title">Choose your template.</h1><p class="page-text mx-auto">Exactly three designs are available. Pick one to generate your portfolio.</p></div>
    <div class="grid lg:grid-cols-3 gap-6">
        @foreach([
            ['simple','Simple','Clean and professional','bg-white text-slate-900'],
            ['modern','Modern','Cards, sections and visual elements','bg-slate-900 text-white'],
            ['creative','Creative','Bold and expressive arrangement','bg-gradient-to-br from-fuchsia-500 to-cyan-400 text-white']
        ] as [$id,$name,$desc,$style])
        <form method="POST" action="{{ route('portfolio.selectTemplate', $portfolio) }}" class="template-option {{ $style }}">
            @csrf
            <input type="hidden" name="template" value="{{ $id }}">
            <div class="template-mini">
                <div class="mini-circle"></div><div class="mini-line"></div><div class="mini-line short"></div>
                <div class="mini-grid"><i></i><i></i><i></i></div>
            </div>
            <h2 class="text-2xl font-black mt-6">{{ $name }}</h2>
            <p class="opacity-70 mt-2 mb-6">{{ $desc }}</p>
            <button class="choose-btn">Use {{ $name }} →</button>
        </form>
        @endforeach
    </div>
</div>
@endsection
