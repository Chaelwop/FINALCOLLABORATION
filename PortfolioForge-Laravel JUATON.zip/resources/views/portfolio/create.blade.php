@extends('layouts.app')
@section('content')
<div class="max-w-5xl mx-auto px-6 py-12">
    <div class="mb-10"><span class="eyebrow">STEP 1 OF 2</span><h1 class="page-title">Tell us about yourself.</h1><p class="page-text">Complete the information below. Your data will be saved in the online database.</p></div>
    <form action="{{ route('portfolio.store') }}" method="POST" enctype="multipart/form-data">@include('portfolio._form')</form>
</div>
@endsection
