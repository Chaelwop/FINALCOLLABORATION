@extends('layouts.app')
@section('content')
<div class="creative-wrap">
    <div class="creative-hero">
        <div class="creative-photo">@if($portfolio->profile_picture)<img src="{{ $portfolio->profile_picture }}">@else{{ strtoupper(substr($portfolio->full_name,0,1)) }}@endif</div>
        <span class="eyebrow">CREATIVE PORTFOLIO</span>
        <h1>{{ $portfolio->full_name }}</h1><p>{{ $portfolio->about_me }}</p>
    </div>
    <div class="creative-content">
        <section class="creative-card"><span>01</span><h2>My Skills</h2><div class="chips">@foreach($portfolio->skills ?? [] as $x)<b>{{ $x }}</b>@endforeach</div></section>
        <section class="creative-card"><span>02</span><h2>Education</h2>@foreach($portfolio->education ?? [] as $x)<p>{{ $x }}</p>@endforeach</section>
        <section class="creative-card wide"><span>03</span><h2>Projects</h2>@foreach($portfolio->projects ?? [] as $x)<div class="creative-project">{{ $x }}</div>@endforeach</section>
        <section class="creative-card"><span>04</span><h2>Experience</h2>@foreach($portfolio->work_experience ?? [] as $x)<p>{{ $x }}</p>@endforeach</section>
        <section class="creative-card"><span>05</span><h2>Contact</h2><p>{{ $portfolio->email }}</p><p>{{ $portfolio->contact_number }}</p><p>{{ $portfolio->address }}</p>@foreach($portfolio->social_links ?? [] as $x)<a href="{{ $x }}" target="_blank" class="block">{{ $x }}</a>@endforeach</section>
    </div>
    <div class="no-print text-center mt-8"><a href="{{ route('portfolio.edit',$portfolio) }}" class="secondary-btn">Edit</a> <button onclick="window.print()" class="primary-btn">Print / Save PDF</button></div>
</div>
@endsection
