@extends('layouts.app')
@section('content')
<div class="portfolio-modern">
    <aside>
        @if($portfolio->profile_picture)<img src="{{ $portfolio->profile_picture }}" class="profile-photo">@endif
        <h1>{{ $portfolio->full_name }}</h1><p>{{ $portfolio->email }}</p><p>{{ $portfolio->contact_number }}</p><p>{{ $portfolio->address }}</p>
        <h3>Skills</h3>@foreach($portfolio->skills ?? [] as $x)<span class="skill-pill">{{ $x }}</span>@endforeach
        <h3>Links</h3>@foreach($portfolio->social_links ?? [] as $x)<a href="{{ $x }}" target="_blank">{{ $x }}</a>@endforeach
    </aside>
    <main>
        <span class="eyebrow">MODERN PORTFOLIO</span><h2>About Me</h2><p class="lead">{{ $portfolio->about_me }}</p>
        <div class="modern-grid">
            <section class="modern-card"><h3>Education</h3>@foreach($portfolio->education ?? [] as $x)<p>▸ {{ $x }}</p>@endforeach</section>
            <section class="modern-card"><h3>Experience</h3>@foreach($portfolio->work_experience ?? [] as $x)<p>▸ {{ $x }}</p>@endforeach</section>
        </div>
        <section class="modern-card"><h3>Featured Projects</h3>@foreach($portfolio->projects ?? [] as $x)<div class="project-row">{{ $x }}</div>@endforeach</section>
        <div class="no-print mt-8"><a href="{{ route('portfolio.edit',$portfolio) }}" class="secondary-btn">Edit</a> <button onclick="window.print()" class="primary-btn">Print / Save PDF</button></div>
    </main>
</div>
@endsection
