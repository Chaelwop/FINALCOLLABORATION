@extends('layouts.app')
@section('content')
<div class="portfolio-simple">
    <div class="portfolio-shell">
        <header class="simple-header">
            @if($portfolio->profile_picture)<img src="{{ $portfolio->profile_picture }}" class="profile-photo">@endif
            <div><p class="eyebrow">PORTFOLIO</p><h1>{{ $portfolio->full_name }}</h1><p>{{ $portfolio->email }} · {{ $portfolio->contact_number }}</p><p>{{ $portfolio->address }}</p></div>
        </header>
        <section><h2>About Me</h2><p>{{ $portfolio->about_me }}</p></section>
        <div class="two-col">
            <section><h2>Education</h2><ul>@foreach($portfolio->education ?? [] as $x)<li>{{ $x }}</li>@endforeach</ul></section>
            <section><h2>Skills</h2><ul>@foreach($portfolio->skills ?? [] as $x)<li>{{ $x }}</li>@endforeach</ul></section>
        </div>
        <section><h2>Projects</h2>@foreach($portfolio->projects ?? [] as $x)<div class="simple-item">{{ $x }}</div>@endforeach</section>
        <section><h2>Experience</h2>@foreach($portfolio->work_experience ?? [] as $x)<div class="simple-item">{{ $x }}</div>@endforeach</section>
        <section><h2>Links</h2>@foreach($portfolio->social_links ?? [] as $x)<a class="link" href="{{ $x }}" target="_blank">{{ $x }}</a>@endforeach</section>
        <div class="mt-8 no-print"><a href="{{ route('portfolio.edit',$portfolio) }}" class="secondary-btn">Edit</a> <button onclick="window.print()" class="primary-btn">Print / Save PDF</button></div>
    </div>
</div>
@endsection
