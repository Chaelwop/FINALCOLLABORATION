@extends('layouts.app')
@section('content')
<div class="max-w-5xl mx-auto px-6 py-12">
    <div class="mb-10"><span class="eyebrow">EDIT PORTFOLIO</span><h1 class="page-title">Update your information.</h1></div>
    <form action="{{ route('portfolio.update', $portfolio) }}" method="POST" enctype="multipart/form-data">@include('portfolio._form')</form>
</div>
@endsection
