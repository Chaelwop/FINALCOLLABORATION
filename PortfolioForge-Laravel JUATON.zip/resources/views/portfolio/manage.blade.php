@extends('layouts.app')
@section('content')
<div class="max-w-6xl mx-auto px-6 py-12">
    <div class="flex flex-wrap items-end justify-between gap-4 mb-10">
        <div><span class="eyebrow">PORTFOLIO MANAGER</span><h1 class="page-title">Your portfolios.</h1></div>
        <a href="{{ route('portfolio.create') }}" class="primary-btn">+ New Portfolio</a>
    </div>
    @forelse($portfolios as $portfolio)
        <div class="manage-card">
            <div class="flex items-center gap-4">
                @if($portfolio->profile_picture)<img src="{{ $portfolio->profile_picture }}" class="avatar">@else<div class="avatar fallback">{{ strtoupper(substr($portfolio->full_name,0,1)) }}</div>@endif
                <div><h2 class="text-xl font-bold">{{ $portfolio->full_name }}</h2><p class="text-slate-400">{{ ucfirst($portfolio->template) }} template · {{ $portfolio->email }}</p></div>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ route('portfolio.show',$portfolio) }}" class="secondary-btn">View</a>
                <a href="{{ route('portfolio.edit',$portfolio) }}" class="secondary-btn">Edit</a>
                <form method="POST" action="{{ route('portfolio.destroy',$portfolio) }}" onsubmit="return confirm('Delete this portfolio?')">@csrf @method('DELETE')<button class="danger-btn">Delete</button></form>
            </div>
        </div>
    @empty
        <div class="empty-card"><h2>No portfolios yet.</h2><p>Create your first portfolio to get started.</p><a href="{{ route('portfolio.create') }}" class="primary-btn mt-5 inline-block">Create Portfolio</a></div>
    @endforelse
</div>
@endsection
