<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'PortfolioForge' }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="{{ asset('css/portfolio.css') }}">
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen">
<nav class="border-b border-white/10 bg-slate-950/90 backdrop-blur sticky top-0 z-50">
    <div class="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="{{ route('home') }}" class="font-black text-xl tracking-tight">Portfolio<span class="text-cyan-400">Forge</span></a>
        <div class="flex gap-2">
            <a href="{{ route('portfolio.manage') }}" class="nav-link">Manage</a>
            <a href="{{ route('portfolio.create') }}" class="nav-button">Create Portfolio</a>
        </div>
    </div>
</nav>

<main>
    @if(session('success'))
        <div class="max-w-6xl mx-auto px-6 pt-6">
            <div class="alert">{{ session('success') }}</div>
        </div>
    @endif

    @if($errors->any())
        <div class="max-w-6xl mx-auto px-6 pt-6">
            <div class="error-box">
                <strong>Please check the form:</strong>
                <ul class="list-disc ml-5 mt-1">
                    @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
                </ul>
            </div>
        </div>
    @endif

    @yield('content')
</main>
</body>
</html>
