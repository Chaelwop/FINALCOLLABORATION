# PortfolioForge — Laravel Portfolio Template Generator

This project is designed directly from the supplied **Online Portfolio Template Generator** requirements.

## Recommended stack
- Laravel 12/13-compatible application
- PHP 8.2+
- Blade
- Tailwind CSS via CDN for simple setup
- PostgreSQL online database (Supabase recommended)
- Render for Laravel hosting

## Required project flow
Home → Create Portfolio → Enter Information → Save Online → Choose 1 of 3 Templates → Generate/Preview → Edit/Delete

## Exactly 3 templates
1. Simple — clean/professional
2. Modern — cards/sections/visual elements
3. Creative — bold/creative layout

## Installation

Create a fresh Laravel project first:

```bash
composer create-project laravel/laravel portfolio-generator
cd portfolio-generator
```

Copy the files in this package into the matching folders of the Laravel project.

Then configure `.env` for your online PostgreSQL database.

Run:

```bash
php artisan migrate
php artisan serve
```

Open:

```text
http://127.0.0.1:8000
```

## PostgreSQL / Supabase
Use the PostgreSQL connection details supplied by your database provider. Do not commit `.env` or database passwords to GitHub.

Typical `.env` values:

```env
DB_CONNECTION=pgsql
DB_HOST=your-host
DB_PORT=5432
DB_DATABASE=postgres
DB_USERNAME=postgres
DB_PASSWORD=your-password
```

## Deployment recommendation
For the assignment, use:
- Database: Supabase PostgreSQL
- Hosting: Render
- Source code: GitHub

The PDF requires the final system to be publicly accessible, use an online database, and support create/retrieve/edit/delete. The deployment URL should be submitted after testing.

## Notes
Profile images are stored as data URLs in the database so the basic project does not depend on local disk storage. The controller limits uploaded images to 2 MB.

For a larger production system, use object storage (such as Supabase Storage) instead.
