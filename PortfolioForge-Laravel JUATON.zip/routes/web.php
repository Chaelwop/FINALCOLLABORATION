<?php

use App\Http\Controllers\PortfolioController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PortfolioController::class, 'home'])->name('home');
Route::get('/portfolio/create', [PortfolioController::class, 'create'])->name('portfolio.create');
Route::post('/portfolio', [PortfolioController::class, 'store'])->name('portfolio.store');
Route::get('/portfolio/{portfolio}/templates', [PortfolioController::class, 'templates'])->name('portfolio.templates');
Route::post('/portfolio/{portfolio}/template', [PortfolioController::class, 'selectTemplate'])->name('portfolio.selectTemplate');
Route::get('/portfolio/{portfolio}', [PortfolioController::class, 'show'])->name('portfolio.show');
Route::get('/portfolio/{portfolio}/edit', [PortfolioController::class, 'edit'])->name('portfolio.edit');
Route::put('/portfolio/{portfolio}', [PortfolioController::class, 'update'])->name('portfolio.update');
Route::delete('/portfolio/{portfolio}', [PortfolioController::class, 'destroy'])->name('portfolio.destroy');

Route::get('/manage', [PortfolioController::class, 'manage'])->name('portfolio.manage');
