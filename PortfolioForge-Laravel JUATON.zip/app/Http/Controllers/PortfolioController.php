<?php

namespace App\Http\Controllers;

use App\Models\Portfolio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PortfolioController extends Controller
{
    public function home()
    {
        return view('home');
    }

    public function manage()
    {
        $portfolios = Portfolio::latest()->get();
        return view('portfolio.manage', compact('portfolios'));
    }

    public function create()
    {
        return view('portfolio.create');
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);

        if ($request->hasFile('profile_picture')) {
            $data['profile_picture'] = $this->imageToDataUrl($request->file('profile_picture'));
        }

        $portfolio = Portfolio::create($data);

        return redirect()
            ->route('portfolio.templates', $portfolio)
            ->with('success', 'Portfolio information saved successfully.');
    }

    public function templates(Portfolio $portfolio)
    {
        return view('portfolio.templates', compact('portfolio'));
    }

    public function selectTemplate(Request $request, Portfolio $portfolio)
    {
        $request->validate([
            'template' => ['required', 'in:simple,modern,creative'],
        ]);

        $portfolio->update(['template' => $request->template]);

        return redirect()->route('portfolio.show', $portfolio);
    }

    public function show(Portfolio $portfolio)
    {
        $view = match ($portfolio->template) {
            'modern' => 'portfolio.templates.modern',
            'creative' => 'portfolio.templates.creative',
            default => 'portfolio.templates.simple',
        };

        return view($view, compact('portfolio'));
    }

    public function edit(Portfolio $portfolio)
    {
        return view('portfolio.edit', compact('portfolio'));
    }

    public function update(Request $request, Portfolio $portfolio)
    {
        $data = $this->validated($request);

        if ($request->hasFile('profile_picture')) {
            $data['profile_picture'] = $this->imageToDataUrl($request->file('profile_picture'));
        } else {
            unset($data['profile_picture']);
        }

        $portfolio->update($data);

        return redirect()->route('portfolio.show', $portfolio)
            ->with('success', 'Portfolio updated successfully.');
    }

    public function destroy(Portfolio $portfolio)
    {
        $portfolio->delete();

        return redirect()->route('portfolio.manage')
            ->with('success', 'Portfolio deleted successfully.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'full_name' => ['required', 'string', 'max:120'],
            'profile_picture' => ['nullable', 'image', 'max:2048'],
            'email' => ['required', 'email', 'max:150'],
            'contact_number' => ['nullable', 'string', 'max:50'],
            'address' => ['nullable', 'string', 'max:255'],
            'about_me' => ['nullable', 'string', 'max:5000'],
            'education' => ['nullable', 'string'],
            'skills' => ['nullable', 'string'],
            'projects' => ['nullable', 'string'],
            'work_experience' => ['nullable', 'string'],
            'social_links' => ['nullable', 'string'],
            'template' => ['nullable', 'in:simple,modern,creative'],
        ]) + [
            'education' => $this->linesToArray($request->input('education')),
            'skills' => $this->linesToArray($request->input('skills')),
            'projects' => $this->linesToArray($request->input('projects')),
            'work_experience' => $this->linesToArray($request->input('work_experience')),
            'social_links' => $this->linesToArray($request->input('social_links')),
        ];
    }

    private function linesToArray(?string $value): array
    {
        return collect(preg_split('/\r\n|\r|\n/', trim((string) $value)))
            ->map(fn ($line) => trim($line))
            ->filter()
            ->values()
            ->all();
    }

    private function imageToDataUrl($file): string
    {
        return 'data:' . $file->getMimeType() . ';base64,' . base64_encode($file->get());
    }
}
